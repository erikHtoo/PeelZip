// PeelZip opt-in read-consumption protocol. No filesystem mutation here.
#ifndef PEELZIP_READ_H
#define PEELZIP_READ_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../../Windows/Synchronization.h"

inline bool PeelEnabled(const char *mode)
{
  const char *value = getenv("PEELZIP_READ_MODE");
  return value && strcmp(value, mode) == 0;
}

inline HRESULT PeelConsumed(const char *mode, unsigned volume, UInt64 offset, UInt64 size)
{
  if (!size || !PeelEnabled(mode)) return S_OK;
  const char *token = getenv("PEELZIP_READ_TOKEN");
  if (!token || strlen(token) != 32) return E_FAIL;
  // Multiple 7z coder input streams may report from different threads.
  static NWindows::NSynchronization::CCriticalSection lock;
  NWindows::NSynchronization::CCriticalSectionLock guard(lock);
  if (printf("\nPEELZIP_READ %s %u %llu %llu\n", token, volume,
      (unsigned long long)offset, (unsigned long long)size) < 0 || fflush(stdout))
    return E_FAIL;
  return getchar() == 'K' ? S_OK : E_ABORT;
}
#endif
